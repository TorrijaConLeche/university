package protectora;

public interface Constantes {
    int NUM_MAX_ANIMALES = 20;
    int NUM_MAX_SOLICITUDES = 20;
    int COSTE_CONTROL_CELO = 14;
    double PRECIO_LEISHMANIA = 35.00;
    double VACUNA_RABIA=40.00;
    double PRECIO_SEDACION=20.00;
    double PIENSO_PERROS_PEQUENOS=0.2;
    double PIENSO_PERROS_MEDIANOS=0.3;
    double PIENSO_PERROS_GRANDES=0.015;
}
